#!/bin/bash
mkdir ~/backup
cp 1.sh  ~/backup/backup.sh
gzip ~/backup/backup.sh
